import React, { Component } from 'react';
import CreatePollForm from '../components/CreatePollForm';


class CreatePoll extends Component {
    render() {
        return (
            <CreatePollForm />
        )
    }
}

export default CreatePoll;