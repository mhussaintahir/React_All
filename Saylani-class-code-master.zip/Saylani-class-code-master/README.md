## Saylani Mass Training Program 
### (Batch 4.1 & 4.2)

Here we will update the code covered in theory classes.

Fork this repositery and make remote of it in your local machine so that whenever we make change you get updates by just executing a command.
